# Directory creation logic
