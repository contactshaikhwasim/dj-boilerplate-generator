# Security helpers
