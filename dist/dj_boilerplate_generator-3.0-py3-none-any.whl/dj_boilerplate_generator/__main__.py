from dj_boilerplate_generator.main import main
if __name__ == "__main__":
    main()
